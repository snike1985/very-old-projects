var mySwiper, scrollWidth;
$(function(){

    var div = document.createElement('div');

    //scroll width
    div.style.overflowY = 'scroll';
    div.style.width = '50px';
    div.style.height = '50px';
    div.style.visibility = 'hidden';

    document.body.appendChild(div);
    scrollWidth = div.offsetWidth - div.clientWidth;
    document.body.removeChild(div);
    //scroll width

    $('.search-btn').on({
        'click':function(){
            var curElem = $('.search'),
                curBtn = $(this);

            if (curElem.hasClass('open')) {
                curElem.removeClass('open');
                curBtn.removeClass('open');
            } else {
                curElem.addClass('open');
                curBtn.addClass('open');
            }

        }
    });

    $('.menu-btn').on({
        'click':function(){
            var curElem = $('.menu'),
                curBtn = $(this);

            if (curElem.hasClass('open')) {
                curElem.removeClass('open');
                curBtn.removeClass('open');
            } else {
                curElem.addClass('open');
                curBtn.addClass('open');
            }

        }
    });

    $('.dropdown dt').on({
        'click':function(){
            var curElem = $(this).parent();

            if (curElem.hasClass('open')) {
                curElem.removeClass('open');
                curElem.find('dd').slideUp();
            } else {
                $('.dropdown').removeClass('open');
                $('.dropdown dd').css({ display: 'none' });
                curElem.addClass('open');
                curElem.find('dd').slideDown();
            }
        }
    });

    $('.streams dt').on({
        'click': function(){
            var curElem = $(this);

            if (curElem.hasClass('active')) {
                curElem.removeClass('active');
            } else {
                $('.streams dt').removeClass('active');
                curElem.addClass('active');
            }

        }
    });

    if ($('.streams').length) {

        $.each($('.streams dd'), function(){
            var elems = $(this);

            var flag = true;

            $.each(elems.find('.streams__menu a'), function(){
                var curElem = $(this);

                if (curElem.hasClass('active')) {
                    flag = false;
                }

            });

            if (flag) {
                elems.find('.streams__menu a:first-child').addClass('active');
                elems.find('.streams__container li:first-child').addClass('active');
            }

        });

    }

    $('.streams__menu a').on({
        'click': function(){
            var curElem = $(this),
                curElemIndex = curElem.index(),
                curParent = curElem.parents('.streams dd');

            if (!curElem.hasClass('active')) {
                curParent.find('.streams__menu a').removeClass('active');
                curParent.find('.streams__container li').removeClass('active');
                curParent.find('.streams__container li').eq(curElemIndex).addClass('active');
                curElem.addClass('active');
            }

            return false;

        }
    });

    $(".menu").niceScroll({
        horizrailenabled: false
    });

    if ( $('.resources .swiper-container').length ){
        if ( $(window).width() < 768 ){
            mySwiper = new Swiper('.resources .swiper-container', {
                pagination: '.swiper-pagination',
                paginationClickable: true,
                spaceBetween: 15,
                slidesPerView: 1.5
            });
        }
    }

    if ( $('.videos .swiper-container').length ){

        var sliderElem = [];

        $.each($('.videos__item'), function(i){
            var curElem = $(this);
            sliderElem[i] = curElem;
            curElem.remove();
        });

        function random(min, max) {
            var range = max - min + 1;
            return Math.floor(Math.random()*range) + min;
        }

        function shuffle(arr) {
            var r_i;
            var v;
            for (var i = 0; i < arr.length-1; i++) {
                r_i = random(0, arr.length-1);
                v = arr[r_i];
                arr[r_i] = arr[arr.length-1];
                arr[arr.length-1] = v;
            }
            return arr;
        }

        shuffle(sliderElem);

        for (var i = 0; i < sliderElem.length; i++) {
            $('.videos .swiper-wrapper').append(sliderElem[i]);
        }

        slider = new Swiper('.videos .swiper-container', {
            slidesPerView: 'auto',
            loopedSlides: 4,
            centeredSlides: false,
            paginationClickable: true,
            loop: true,
            spaceBetween: 0,
            autoplay: 5000,
            speed: 600,
            nextButton: $('.videos__next'),
            prevButton: $('.videos__prev')
        });

    }

    $.each( $(".your-reaction__level"), function(){
        new ShowRating ( $(this) );
    } );

    $.each( $('.single-post'), function(){
        new ShowContent ( $(this) )
    } );

    $('.popup').each(function(){
        new Popup($(this));
    });

    $('.connect-with__subscribe').each(function(){
        new Subscribe ($(this));
    });

    $('.filter > dt').on({
        'click':function(){
            var curElem = $(this).parent();

            if (curElem.hasClass('filter_open')) {
                curElem.removeClass('filter_open');
                curElem.find('>dd').slideUp();
            } else {
                $('.dropdown dd').css({ display: 'none' });
                curElem.addClass('filter_open');
                curElem.find('dd').slideDown();
            }
        }
    });

} );

$(window).on({
    'load': function(){
        $('.menu').css({ height: $(window).outerHeight() - 60 });

        if ($(window).width() > (1023 - scrollWidth)) {
            var curScroll = $(window).scrollTop(),
                curHeaderLayout = $('.site__header-layout'),
                curHeader = $('.site__header');

            if (curScroll < curHeader.outerHeight()) {
                curHeader.addClass('static');
                curHeaderLayout.css({ top: -curScroll });
            } else {
                curHeader.removeClass('static');
                curHeaderLayout.css({ top: 0 });
            }
        }

    },
    'resize': function(){
        $('.menu').css({ height: $(window).outerHeight() - 60 });

        if ( $('.resources .swiper-container').length ){

            if ( $(window).width() > 767 - scrollWidth ){

                if (typeof mySwiper != 'undefined') {
                    mySwiper.destroy();
                    mySwiper = undefined;
                    $('.swiper-wrapper').removeAttr('style');
                    $('.swiper-slide').removeAttr('style');
                }

            } else {
                if (typeof mySwiper == 'undefined') {
                    mySwiper = new Swiper('.resources .swiper-container', {
                        pagination: '.swiper-pagination',
                        paginationClickable: true,
                        spaceBetween: 15,
                        slidesPerView: 1.5
                    });
                }

            }

        }

    },
    'scroll': function(){

        if ($(window).width() > (1023 - scrollWidth)) {
            var curScroll = $(window).scrollTop(),
                curHeaderLayout = $('.site__header-layout'),
                curHeader = $('.site__header');

            if (curScroll < curHeader.outerHeight()) {
                curHeader.addClass('static');
                curHeaderLayout.css({ top: -curScroll });
            } else {
                curHeader.removeClass('static');
                curHeaderLayout.css({ top: 0 });
            }
        }


    }
});

var ShowRating = function (obj) {
    this.obj = obj;
    this.init();
};
ShowRating.prototype = {
    init: function(){
        var self = this;
        self.core = self.core();
        self.core.build();
    },
    core: function(){
        var self = this;

        return {
            build: function(){
                self.indexWrap = self.obj.find(".your-reaction__index");
                self.index = self.indexWrap.data("index");
                self.mobileWrap = self.obj.find(".your-reaction__index-mobile");
                self.val = self.obj.find(".your-reaction__index-value");
                self.tabletWrap = self.obj.find(".your-reaction__index-tablet");
                self.mobileWrap.css({
                    "width": self.index + "%"
                });
                self.tabletWrap.css({
                    "height": self.index + "%"
                });
                self.val.css({
                    "left": self.index + "%",
                    "bottom": self.index + "%"
                });
            }
        };
    }
};

var ShowContent = function( obj ){
    this.obj = obj;

    this.init();
};
ShowContent.prototype = {
    init: function(){
        var self = this;
        self.core = self.core();
        self.core.build();
    },
    core: function(){
        var request = new XMLHttpRequest(),
            self = this;

        return {
            build: function(){
                self.core.AddEvents();
            },
            AddEvents: function(){

                $(window).on({
                    scroll: function(){
                        var scrollPosition = $(window).scrollTop(),
                            docHeight = $(document).height(),
                            windowHeight = $(window).height();
                        if ( scrollPosition > docHeight - windowHeight - 500 ){
                            self.core.addContent();
                        }
                    }
                });
            },
            addContent: function(){

                request.abort();
                var inner = $('.site__content-inner'),
                    preloader = inner.find('>.fa-refresh');
                request = $.ajax({
                    url: self.obj.attr('data-action'),
                    data: {
                        loadedCount: $(".single-post__theme").length
                    },
                    dataType: 'json',
                    timeout: 20000,
                    type: "GET",
                    success: function (msg) {
                        if(!msg.needElems == "0"){
                            var contentMsg = msg.html;
                            inner.append(contentMsg);
                            $.each( $(".your-reaction__level"), function(){
                                new ShowRating ( $(this) );
                            } );
                        } else {
                            preloader.remove();
                        }
                    },
                    error: function (XMLHttpRequest) {
                        if (XMLHttpRequest.statusText != "abort") {
                            alert("ERROR!");
                        }
                    }
                });
            }
        };
    }
};

var Popup = function( obj ){
    this.popup = obj;
    this.popupWrap = this.popup.find( '.popup__wrap' );
    this.popupContent = this.popup.find( '.popup__content' );
    this.btnShow =  $('.popup__open');
    this.btnClose = this.popup.find( '.popup__close' );
    this.wrap = this.popup.find(".popup__close");
    this.window = $( window );

    this.init();
};
Popup.prototype = {
    init: function(){
        var self = this;
        self.core = self.core();
        self.core.build();
    },
    core: function (){
        var self = this;

        return {
            build: function (){
                self.core.controls();
            },
            controls: function(){
                self.btnShow.on( {
                    click: function(){
                        var dataClass = $(this).attr('data-popup'),
                            curPopup = self.popup.filter(".popup_"+ dataClass);
                        curPopup.addClass("popup_opened");
                        return false;
                    }
                } );
                self.btnClose.on( {
                    click: function(){
                        var curPopup = $(this).parents(".popup");
                        curPopup.removeClass("popup_opened");
                        return false;
                    }
                } );
                self.popupWrap.click( function(){
                    var curPopup = $(this).parents(".popup");
                    curPopup.removeClass("popup_opened");
                    return false;
                });
                self.popupContent.on({
                    click: function(event){
                        event = event || window.event;
                        event.stopPropagation();
                    }
                });
            }

        };
    }
};

var Subscribe = function (obj) {
    this.obj = obj;
    this.input = this.obj.find("input");
    this.emailField = this.obj.find(".connect-with__email");
    this.popupEror = $(".popup_error");
    this.popupThanks = $(".popup_thanks");

    this.init();
};
Subscribe.prototype = {
    init: function(){
        var self = this;
        self.core = self.core();
        self.core.build();
    },
    core: function(){
        var self = this;
        var request = new XMLHttpRequest();

        return {
            build: function(){
                self.core.controls();
            },
            controls: function(){
                self.obj.on({
                    'submit': function () {
                        var inputTextVal = self.input.val();
                        if(!(self.input.val()=='')){

                            if(self.core.isValidEmailAddress(inputTextVal)){
                                self.core.ajaxRequest();
                                self.emailField.removeClass("connect-with__email_error");


                            }else{
                                self.emailField.addClass("connect-with__email_error");
                                self.popupEror.addClass("popup_opened");
                                setTimeout( function(){
                                    self.popupEror.removeClass("popup_opened");
                                },5000 );
                            }

                        }else{
                            self.emailField.addClass("connect-with__email_error");
                            self.popupEror.addClass("popup_opened");
                            setTimeout( function(){
                                self.popupEror.removeClass("popup_opened");
                            },3000 );
                        }

                        return false;
                    }
                });
            },
            ajaxRequest: function () {
                request.abort();
                request = $.ajax({
                    url: self.obj.attr('action'),
                    data: self.obj.serialize(), // отправляет всю форму
                    dataType: 'html',
                    timeout: 20000,
                    type: "POST",
                    success: function (msg) {
                        self.obj.trigger('reset');
                        self.popupThanks.addClass("popup_opened");
                        setTimeout( function(){
                            self.popupThanks.removeClass("popup_opened");
                        },4000 );
                    },
                    error: function (XMLHttpRequest) {
                        if (XMLHttpRequest.statusText != "abort") {
                            alert("Error!");
                        }
                    }
                });
            },

            isValidEmailAddress: function(emailAddress) {
                var pattern = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
                return pattern.test(emailAddress);
            }
        };
    }
};